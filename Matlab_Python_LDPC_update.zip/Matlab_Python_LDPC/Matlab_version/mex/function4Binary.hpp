#ifndef H_FUNCTION4Binary
#define H_FUNCTION4Binary

void ArrayMultiply4Binary(int *res, const int *a, const int* b, int n, int l);
void ArrayMultiply4Binary(int *res, const int *a, const char* b, int n, int l);

#endif
