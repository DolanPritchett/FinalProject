#ifndef _EXAMPLE_MEX_CLASS_H
#define _EXAMPLE_MEX_CLASS_H

class example
{
public:
	example();
public:
	int a;
	int b;
};

#endif