#include "example_mex_class.h"

example::example()
{
	a = 0;
	b = 0;
}