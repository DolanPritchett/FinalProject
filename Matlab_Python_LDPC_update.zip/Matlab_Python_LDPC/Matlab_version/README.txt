author      : Xiang Huang
date        : 3/21/2022
last update : 3/21/2022

This matlab version provides the decoder and encoder of LDPC codes.
You can check Matlab_LDPC.m to see how to use decoder and encoder.
5G (2560,1280) LDPC code is "5G_LDPC_M10_N20_Z128_Q2_nonVer.txt"