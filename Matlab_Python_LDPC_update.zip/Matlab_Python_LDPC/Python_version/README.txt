You can check the "main.py" to see how to use the encoder and decoder.

5G (2560,1280) LDPC code is "5G_LDPC_M10_N20_Z128_Q2_nonVer.txt"

The example code will run this 5G (2560,1280) LDPC code with sum-product algorithm on AWGN channel.

To run this code, you need to install pybind11. 

pip install pybind11