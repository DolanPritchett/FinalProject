import numpy as np

def BCJR_decoder2(gen_poly,srcc_en,max_log_map_en,term_en,La,EsN0,received_seq):

    #Conversion of Binary to Python Integer List: '0b1101'=> [1,1,0,1]
    #the Leftest bit is LSB. ex) 1101 => G(D)=1+D+D^3 (not 1+D^2+D^3)
    def bitfield(n):
        return [int(digit) for digit in bin(n)[2:]] # [2:] to chop off the "0b" part

    #Conversion of Binary Integer List to Decimal: [1,1,0,1] => 11 
    #the Leftest bit is LSB. ex) [1,1,0,1] => 11 (not 7!!)
    def intconv(n):
        intout=0
        for idx, digit in enumerate(n):
            #print(f'idx:{idx}, digit:{digit}')
            #intout+=digit*2**(len(n)-idx)
            intout+=digit*2**idx    
        return intout

    def max_exp2(x,y):
        #return max(x,y)+np.log(1+np.exp(-np.abs(x-y)))
        return np.round(max(x,y)+np.log(1+np.exp(-np.abs(x-y))),decimals=4)                
    def max_exp(max_log_map_en, x):
        if max_log_map_en==True:
            return max(x)
        else:
            return x[0] if len(x)==1 else max_exp2(x[-1],max_exp(max_log_map_en,x[0:-1]))

    def fsm_table_srcc_gen(v,bitpoly):
        state_idx=np.linspace(0,2**v-1,2**v,dtype=int)
        state_reg=[bitfield(state_idx[i]) for i in range(2**v)]

        for i in range(len(state_idx)):
            state_reg[i]=[0] * (v-len(state_reg[i])) + state_reg[i] if len(state_reg[i]) < v else state_reg[i]  #polynomial bitwitdh matching

        fsm_table=[['none' for i in range(2**v)] for j in range(2**v)]

        for idx, shft_reg_in in enumerate(state_reg):        
            for i in range(2):
                shft_reg=np.asarray(shft_reg_in)
                in_state=intconv(shft_reg)
                #print(f'input:{i}, in state:{in_state}, shift reg:{shft_reg}')    
                j1=i  #SRCC
                #Feedback Loop    
                temp=i*bitpoly[0][0]
                for j in range(v):        
                    temp=temp^shft_reg[j]*bitpoly[0][j+1]    
                
                #Forward Path
                j2=temp*bitpoly[1][0]
                for j in range(v):        
                    j2=j2^shft_reg[j]*bitpoly[1][j+1]
                #print(f'temp:{temp}, j2:{j2}')   
                #Register Shift
                shft_reg[1:shft_reg.size]=shft_reg[0:shft_reg.size-1]
                shft_reg[0]=temp

                #FSM Output        
                out_state=intconv(shft_reg)
                #print(f'out state:{out_state}, shift reg:{shft_reg}')  
                fsm_table[in_state][out_state]=[i, j1, j2]            
        
        return fsm_table

    def fsm_table_ff_gen(v,bitpoly):
        state_idx=np.linspace(0,2**v-1,2**v,dtype=int)
        state_reg=[bitfield(state_idx[i]) for i in range(2**v)]

        for i in range(len(state_idx)):
            state_reg[i]=[0] * (v-len(state_reg[i])) + state_reg[i] if len(state_reg[i]) < v else state_reg[i]  #polynomial bitwitdh matching

        fsm_table=[['none' for i in range(2**v)] for j in range(2**v)]

        for idx, shft_reg_in in enumerate(state_reg):    
            for i in range(2):        
                shft_reg=np.asarray(shft_reg_in)
                in_state=intconv(shft_reg)
                #print(f'in state:{in_state}, shift reg:{shft_reg}')    
                #Feedforward
                j1=i*bitpoly[0][0]
                j2=i*bitpoly[1][0]
                for j in range(len(bitpoly[0])-1):
                    j1=j1^shft_reg[j]*bitpoly[0][j+1]
                    j2=j2^shft_reg[j]*bitpoly[1][j+1]
                
                #Register Shift
                shft_reg[1:shft_reg.size]=shft_reg[0:shft_reg.size-1]
                shft_reg[0]=i        

                #FSM Output
                out_state=intconv(shft_reg)
                #print(f'out state:{out_state}, shift reg:{shft_reg}')   
                fsm_table[in_state][out_state]=[i, j1, j2]
        
        return fsm_table

    def bcjr_branch_metric(La,u_l,EsN0,rx_vec,code_vec):
        #BCJR branch metric
        Lc=4*EsN0        
        n=len(code_vec) #code length at each trellis section    
        u_l2=2*(u_l-0.5)
        #print(f'u_l:{u_l}, u_l2:{u_l2}')
        corr=0.0
        for i in range(n):
            corr+=2*(code_vec[i]-0.5)*rx_vec[i]
        #Maximizing log-likelihood function is equivalent to finding 'maximum' path metric
        #cal_metric=2*(codeword[1]-0.5)*received_seq[0]+2*(codeword[2]-0.5)*received_seq[1]    
        gamma=u_l2*(La/2)+(Lc/2)*(corr)

        return gamma

    #Generalized Gamma
    def bcjr_gamma_table_gen2(La,EsN0,h,m,v,fsm_table,received_seq):        
        #gamma_table dimension: time index x leaving state x arriving state
        gamma_table=[[['none' for i in range(2**v)] for j in range(2**v)] for k in range(h+m)] 

        for k in range(h+m): #time index
            for i in range(2**v): #leaving state index
                for j in range(2**v): #arriving state index
                    if fsm_table[i][j]!='none':                                                        
                        #print(f'k index:{k}, La_ul:{La[k]}')
                        #print(f'k index:{k},{i},{j}')
                        if len(La)<h:
                            print(f'ERROR: the number of La is smaller than information sequence')
                            exit()
                        elif k<len(La):
                            La_ul=La[k]                            
                        else:  #if all or some termination bits don't have a priori LLR
                            print(f'La is shorter than input sequence and put zero value in place')
                            La_ul=0
                        u_l=fsm_table[i][j][0]
                        rx_vec= received_seq[k]
                        code_vec=fsm_table[i][j][1:3]                                                                
                        #gamma_table[k][i][j]=bcjr_branch_metric(La_ul,u_l,EsN0,rx_vec,code_vec)
                        gamma_table[k][i][j]=np.round(bcjr_branch_metric(La_ul,u_l,EsN0,rx_vec,code_vec),decimals=4)
                        
        return gamma_table

    #Generalized Alpha Table Generation
    def bcjr_alpha_table_gen2(h,m,v,max_log_map_en,fsm_table,gamma_table):
        #alpha_table dimension: time index x state index
        alpha_table=[['none' for i in range(2**v)] for k in range(h+m)]
        for k in range(h+m):
            for i in range(2**v):
                #alpha table intialization
                if k==0:
                    if i==0: #alpha(s0) at t=0
                        alpha_table[k][i]=0
                    else:    #alpha values of other states at t=0
                        alpha_table[k][i]=-50            
                
                #alpha table generation
                else:
                    max_list=[]
                    #for j in range (len(gamma_table[0])):
                    for j in range (2**v):
                        if fsm_table[j][i]!='none':
                            max_list.append(alpha_table[k-1][j]+gamma_table[k-1][j][i])
                        #if gamma_table[k-1][j][i]!='none':
                        #    max_list.append(alpha_table[k-1][j]+gamma_table[k-1][j][i])
                    alpha_table[k][i]=max_exp(max_log_map_en,max_list)                        
                    #if len(max_list)==0:
                    #    alpha_table[k][i]=-500
                    #else:                
                        #alpha_table[k][i]=max_exp(max_list[0],max_list[1])
                        #alpha_table[k][i]=max_exp(max_list)
        return alpha_table

    #Generalized Beta Table Generation
    def bcjr_beta_table_gen2(h,m,v,max_log_map_en,term_en,fsm_table,gamma_table):
        #beta_table dimension: time index x state index
        beta_table=[['none' for i in range(2**v)] for k in range(h+m+1)]

        for k in range(h+m,0,-1):
            for i in range(2**v):
                #beta table intialization
                if k==h+m:
                    if i==0:  #beta(s0) at t=h+m
                        beta_table[k][i]=0
                    else:
                        beta_table[k][i]=-50 if term_en==True else 0
                
                #beta table generation
                else:
                    max_list=[]
                    for j in range (len(gamma_table[0])):
                        if fsm_table[i][j]!='none':
                            max_list.append(beta_table[k+1][j]+gamma_table[k][i][j])
                        #print(k,i,j)
                        #if gamma_table[k][i][j]!='none':
                        #    max_list.append(beta_table[k+1][j]+gamma_table[k][i][j])
                    #print(f'max list length:{len(max_list)}')                
                    beta_table[k][i]=max_exp(max_log_map_en,max_list)

                    #if len(max_list)==0:
                    #    beta_table[k][i]=-500
                    #else:                
                        #beta_table[k][i]=max_exp(max_list[0],max_list[1])
                        #beta_table[k][i]=max_exp(max_list)
        return beta_table

    n=len(gen_poly) #Code parameter n

    bitpoly=[bitfield(gen_poly[i]) for i in range(n)]
    v=max( len(bitpoly[i]) for i in range(n) )-1 #memory size

    for i in range(n):
        bitpoly[i]=[0] * (v+1-len(bitpoly[i])) + bitpoly[i] if len(bitpoly[i]) < v+1 else bitpoly[i]  #polynomial bitwitdh matching

    if srcc_en==True:
        fsm_table=fsm_table_srcc_gen(v,bitpoly)
    else:
        fsm_table=fsm_table_ff_gen(v,bitpoly)
    
    m=v
    h=len(received_seq)-m    

    gamma_table=bcjr_gamma_table_gen2(La,EsN0,h,m,v,fsm_table,received_seq)
    alpha_table=bcjr_alpha_table_gen2(h,m,v,max_log_map_en,fsm_table,gamma_table)
    beta_table=bcjr_beta_table_gen2(h,m,v,max_log_map_en,term_en,fsm_table,gamma_table)

    ## LLR Generation
    llr=np.zeros(h+m)
    for k in range(h+m):
        positive_list=[]
        negative_list=[]
        for i in range(2**v):
            for j in range(2**v):
                if gamma_table[k][i][j]!='none' and fsm_table[i][j][0]==1:  #postive info bit
                    #print(f'positive:{k,i,j}')
                    positive_list.append(alpha_table[k][i]+gamma_table[k][i][j]+beta_table[k+1][j])
                
                if gamma_table[k][i][j]!='none' and fsm_table[i][j][0]==0:  #postive info bit
                    #print(f'negative:{k,i,j}')
                    negative_list.append(alpha_table[k][i]+gamma_table[k][i][j]+beta_table[k+1][j])

        #print(f'time index:{k}')    
        #print(f'positive list lenght:{len(positive_list)}') 
        #print(f'negative list lenght:{len(negative_list)}') 
        #print()
        #if len(positive_list)==0:
        #    llr[k]=-max_exp(negative_list)
        #elif len(negative_list)==0:
        #    llr[k]=max_exp(positive_list)
        #else:
        #    llr[k]=max_exp(positive_list)-max_exp(negative_list)

        llr[k]=max_exp(max_log_map_en,positive_list)-max_exp(max_log_map_en,negative_list)        
        decod_seq=np.where(llr>0.0, 1, 0)
    
    #return llr,decod_seq
    return llr,decod_seq, fsm_table, gamma_table, alpha_table, beta_table

def interleaver(intlv_pattern,in_seq):    
    if len(intlv_pattern)!=len(in_seq):
        print(f'ERROR: interleaver pattern length is not matched with input sequence')
        return None
        
    out_seq=[]
    for i in range(len(in_seq)):        
        out_seq+=[in_seq[intlv_pattern[i]]]
    out_seq=np.array(out_seq)
    return out_seq

def de_interleaver(intlv_pattern,in_seq):    
    if len(intlv_pattern)!=len(in_seq):
        print(f'ERROR: interleaver pattern length is not matched with input sequence')
        return None
    
    de_intlv_pattern=np.zeros(len(intlv_pattern),dtype=int)
    for i,index in enumerate(intlv_pattern):
        de_intlv_pattern[index]=i
    #print(f'de-interleaver pattern:\n{de_intlv_pattern}')

    out_seq=[]
    for i in range(len(in_seq)):               
        out_seq+=[in_seq[de_intlv_pattern[i]]]        
    out_seq=np.array(out_seq)
    return out_seq

def depuncturing(received_seq,code_block_len,num_pccc,punc_mat):
    # code_block_len: the length of code block
    # ex) n,k,m convolutional code, if k is 1000 and m is 5, and R=1/3
    # then code_block_len is k+m=1005 and total code length is (k+m)*(1/R)
    # num_pccc: the number of constituent codes

    k=code_block_len*(num_pccc+1) 
    #total code length without puncturing if each constituent code has R=1/2

    punc_vec=punc_mat.flatten()
    depunc_out=np.array([])

    j=0
    for i in range(k):
        if punc_vec[i%len(punc_vec)]==True:
            depunc_out=np.append(depunc_out,received_seq[j])
            j+=1
        else:
            depunc_out=np.append(depunc_out, 0.0)
    
    return depunc_out

######################################################
#### Code Review Set Generation for Turbo Decoder ####
######################################################
# Turbo Decoder Test
# received_seq: In the textbook example, received sequence is channel L values=Lc*r 
# but, in this code, input is just r so if the received sequece is L value,
# it has to be modified before feeding into the code
# Lc: channel reliability factor= 4*(Es/N0)
######################################################

#########################
##     Example 16.4    ##
#########################
# #'''
# srcc_en=True
# max_log_map_en=False
# dec1_term_en=True
# dec2_term_en=True
# gen_poly=[0o3,0o2]
# intlv_pattern=np.array([1,3,2,4])
# intlv_pattern=intlv_pattern-1
# punc_matrix=np.array([[True, True],[True, True],[True,True]]).T
# punc_en=False
# num_pccc=2

# received_seq=np.array([0.8, 0.1, -1.2, 1.0, -0.5, 1.2, -1.8, 1.1, 0.2, 1.6, -1.6, -1.1])
# code_block_len=4# 3(info)+1(term)

# #EsN0=EbN0-10log10(k)-10log10(R) in which k bits per symbol and R is code rate
# EsN0=1/4

# #received_seq: In the textbook example, received sequence is channel L values=Lc*r 
# #but, in this code, input is just r so if the received sequece is L value,
# #it has to be modified before feeding into the code
# Lc=4*EsN0
# received_seq=(1/Lc)*received_seq  
# #'''

#########################
## Code Review Input 1 ##
#########################
# #'''
# srcc_en=True
# max_log_map_en=False
# dec1_term_en=True
# dec2_term_en=False
# gen_poly=[0o7,0o5]
# intlv_pattern=np.array([12, 5, 9, 2, 10, 7, 1, 14, 6, 11, 3, 8, 4, 13])
# intlv_pattern=intlv_pattern-1
# punc_matrix=np.array([[True, True],[True, False],[False,True]]).T
# punc_en=True
# num_pccc=2

# received_seq=np.array([1.2, -0.8, -0.2, 1.5,\
#     -0.3, -0.6, 1.1, 2.0, \
#     2.5, 0.7, -0.2, 0.1, \
#     -1.6, -1.3, -0.4, 0.9,\
#     -2, -0.25, 0.5, 0.4,\
#     0.15, -1.5, 3, -0.9,\
#     0.4, 2.2, -1.8, 1.4])

# code_block_len=14 #12(info)+2(term)

# #EsN0=EbN0-10log10(k)-10log10(R) in which k bits per symbol and R is code rate
# #EsN0=10**(-1/10) #-1dB, EbN0=2dB, 
# EsN0=np.round(10**(-1/10),decimals=4) #-1dB, EbN0=2dB, 
# #'''


#########################
## Code Review Input 2 ##
#########################
#'''
srcc_en=True
max_log_map_en=False
dec1_term_en=True
dec2_term_en=False
gen_poly=[0o37,0o21]
intlv_pattern=np.array([5, 7, 16, 4, 1, 19, 10, 15, 3, 20, 12, 8, 14, 2, 17, 11, 18, 6, 13, 9])
intlv_pattern=intlv_pattern-1
punc_matrix=np.array([[True, True],[True, False],[False,True]]).T
punc_en=True
num_pccc=2

received_seq=np.array([2, -0.5, 1, 0.9,\
     1.2, -0.8, -1.0, -0.3,\
    -0.5,  1.6, -0.8,  2.0,\
    -0.9, -1.3,  0.6,  1.2,\
    -1.6,  0.5, -1.4, -1.6,\
     0.3,  1.6, -0.2,  2.5,\
    -3.2,  2.0, -1.4,  0.7,\
     2.2, -1.2,  2.0, -1.3,\
     1.6, -0.4, -1.6,  1.8,\
    -1.8, -2.5,  1.1, -2.0])

code_block_len=20 #14(info)+6(term)

#EsN0=EbN0-10log10(k)-10log10(R) in which k bits per symbol and R is code rate
EsN0=10**(0/10) #0dB
#'''

num_iter=10

if punc_en==True:
    depunc_out=depuncturing(received_seq,code_block_len,num_pccc,punc_matrix)
    received_seq=depunc_out

Lc=4*EsN0

#received_seq_tmp=received_seq.reshape(code_block_len,num_pccc+1)
received_seq_tmp=received_seq.reshape(code_block_len,-1)

received_seq1=received_seq_tmp[:,0:2]

intlevd_received_infobit=interleaver(intlv_pattern,received_seq_tmp[:,0])
#received_seq2=np.concatenate((intlevd_received_infobit.reshape(info_block_len,1),received_seq_tmp[:,2].reshape(info_block_len,1)),axis=1)
received_seq2=np.concatenate((np.expand_dims(intlevd_received_infobit, axis=1),np.expand_dims(received_seq_tmp[:,2], axis=1)),axis=1)

for i in range(num_iter):
    print(f'iteration number:{i+1}')

    ## Decoder 1 ##    
    if i==0:
        La=np.zeros(len(received_seq1))
    else:
        La_tmp=ext_llr
        La=de_interleaver(intlv_pattern,La_tmp)
    #print(f'La to decoder1:{La}')
    received_seq_input=received_seq1
    llr,decod_seq,fsm_table,gamma_table, alpha_table, beta_table=BCJR_decoder2(gen_poly,srcc_en,max_log_map_en,dec1_term_en,La,EsN0,received_seq_input)
    ext_llr=llr-La-Lc*received_seq_tmp[:,0]    
    #print(f'Extrinsic LLR from decoder1:\n{np.round(ext_llr,decimals=4)}')
    print(f'Extrinsic LLR from decoder1:\n{ext_llr}')
    #print(f'Extrinsic LLR from decoder1:\n{np.round(ext_llr,4)}')
    #print(f'Prior LLR for decoder 1:\n{La}')
    #print(f'Full LLR from decoder 1:\n{llr}')
    #print(f'input to decoder 1:\n{Lc*received_seq_tmp[:,0]}')
    #fsm_gamma_alpha_beta_table_disp(gen_poly,fsm_table,gamma_table,alpha_table,beta_table)

    ## Decoder 2 ##
    La_tmp=ext_llr
    La=interleaver(intlv_pattern,La_tmp)
    
    #print(f'La to decoder2:{La}')
    received_seq_input=received_seq2
    llr,decod_seq,fsm_table,gamma_table, alpha_table, beta_table=BCJR_decoder2(gen_poly,srcc_en,max_log_map_en,dec2_term_en,La,EsN0,received_seq_input)
    ext_llr=llr-La-Lc*intlevd_received_infobit
    
    print(f'Extrinsic LLR from decoder2:\n{ext_llr}')
    #print(f'Extrinsic LLR from decoder2:\n{np.round(ext_llr,4)}')
    #print(f'Prior LLR for decoder 2:\n{La}')
    #print(f'Full LLR from decoder 2:\n{llr}')
    #print(f'input to decoder 2:\n{Lc*intlevd_received_infobit}')
    #fsm_gamma_alpha_beta_table_disp(gen_poly,fsm_table,gamma_table,alpha_table,beta_table)

    siso_out=de_interleaver(intlv_pattern,llr)
    print(f'full LLR from decoder2:\n{llr}')
    #print(f'full LLR from decoder2:\n{np.round(llr,4)}')
    #print(f'full LLR from decoder2:\n{np.round(llr,decimals=4)}')
    print(f'deinterleaved Soft-output L-values:\n{siso_out}')
    #print(f'deinterleaved Soft-output L-values:\n{np.round(siso_out,decimals=4)}')    
    print()